// App.js
import React from 'react';
import SignIn from './components/SignIn';
import './index.css';

const App = () => {
  return (
    <div className="app">
        <div className='parent'>
        <SignIn />
        </div>

    </div>
  );
};

export default App;
